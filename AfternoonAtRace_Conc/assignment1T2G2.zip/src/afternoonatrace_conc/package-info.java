/**
 * Package with all sub-packages.
 *
 *	- Shared Regions
 *	- Entities
 *	- Main
 */
package afternoonatrace_conc;