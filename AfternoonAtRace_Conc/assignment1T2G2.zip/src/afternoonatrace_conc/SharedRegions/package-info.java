/**
 * Package with all the shared regions used.<br>
 *  - BettingCenteer<br>
 *  - ControlCenter<br>
 *  - Stable<br>
 *  - Paddock<br>
 *  - RaceTrack<br>
 * Also contains a General repository used to create a log file.
 */
package afternoonatrace_conc.SharedRegions;