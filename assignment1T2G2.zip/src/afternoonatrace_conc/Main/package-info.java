/**
 * Package with the Main and Simulation Parameters.
 */
package afternoonatrace_conc.Main;