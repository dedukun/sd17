/**
 * Package with all the entities used in this problem.<br>
 *  - Broker<br>
 *  - HorseJockey<br>
 *  - Spectators
 */
package afternoonatrace_conc.Entities;